$(document).ready(function(){
    $("#test").click(function(){
        $(".dropdown").toggle()
    })
})

